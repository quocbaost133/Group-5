<?php
$conn = mysqli_connect("localhost", "root", "", "test") or die("Không thể kết nối csdl.");
?>